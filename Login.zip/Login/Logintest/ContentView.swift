//
//  ContentView.swift
//  login
//
//  Created by ZhongzhengSU on 21/1/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        LoginView()  // 显示登录视图
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
