import SwiftUI

struct MainView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Welcome to MyfoodChoice")
                    .font(.title)
                    .foregroundColor(Color("IconGreen"))
                
                Text("Login Successful!")
                    .font(.subheadline)
                    .padding(.top, 10)
                
                Button(action: {
                    // 返回登录页面
                    dismiss()
                }) {
                    Text("Logout")
                        .foregroundColor(.white)
                        .frame(width: 200, height: 45)
                        .background(Color("IconGreen"))
                        .cornerRadius(8)
                }
                .padding(.top, 30)
            }
            .navigationBarTitle("Home", displayMode: .inline)
        }
    }
}

#Preview {
    MainView()
} 