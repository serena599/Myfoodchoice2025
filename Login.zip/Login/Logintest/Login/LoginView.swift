import SwiftUI

struct LoginView: View {
    @StateObject private var viewModel = LoginViewModel()
    @State private var showMainView = false
    @State private var showSignUp = false

    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("IconGreen").ignoresSafeArea()

                VStack(spacing: 0) {
                    Text("MyfoodChoice")
                        .font(.system(size: 42, weight: .bold))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.2), radius: 2, x: 0, y: 2)
                        .padding(.top, 70)
                        .padding(.bottom, 230)

                    VStack(spacing: 25) {
                        
                        //username
                        HStack {
                            Image(systemName: "person")
                                .foregroundColor(.white)
                                .padding(.leading, 8)
                            TextField("USERNAME", text: $viewModel.username)
                                .foregroundColor(.white)
                                .accentColor(.white)
                        }
                        .frame(height: 45)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.white, lineWidth: 1)
                        )
                        .padding(.horizontal, 30)
                        
                        // Password
                        HStack {
                            Image(systemName: "lock")
                                .foregroundColor(.white)
                                .padding(.leading, 8)
                            SecureField("Password", text: $viewModel.password)
                                .foregroundColor(.white)
                                .accentColor(.white)
                        }
                        .frame(height: 45)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.white, lineWidth: 1)
                        )
                        .padding(.horizontal, 30)
                        
                        // login
                        Button(action: {
                            if !viewModel.isLoading {
                                viewModel.isLoading = true
                                viewModel.login { success in
                                    if success {
                                        showMainView = true
                                    }
                                    viewModel.isLoading = false
                                }
                            }
                        }) {
                            ZStack {
                                if viewModel.isLoading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                } else {
                                    Text("LOGIN")
                                        .font(.system(size: 16))
                                        .foregroundColor(Color("IconGreen"))
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 45)
                            .background(viewModel.isLoading ? Color.gray : Color.white)
                            .cornerRadius(8)
                        }
                        .disabled(viewModel.isLoading)
                        .padding(.horizontal, 30)
                        .padding(.top, 20)
                        .animation(.easeInOut, value: viewModel.isLoading)

                        if let errorMessage = viewModel.errorMessage {
                            Text(errorMessage)
                                .foregroundColor(.red)
                                .font(.caption)
                                .padding(.horizontal, 30)
                        }

                        // Button
                        HStack {
                            Button("Sign up") {
                                showSignUp = true
                            }
                            .foregroundColor(.white)
                            
                            Spacer()
                            
                            Button("Forgot password?") {
                                //
                            }
                            .foregroundColor(.white)
                        }
                        .padding(.horizontal, 40)
                        .padding(.top, 2)
                        
                        Spacer()
                    }
                }
            }
            .navigationDestination(isPresented: $showMainView) {
                MainView()
                    .navigationBarBackButtonHidden(true)
            }
            .navigationDestination(isPresented: $showSignUp) {
                SignUpView()
            }
        }
    }
}



#Preview {
    LoginView()
}

