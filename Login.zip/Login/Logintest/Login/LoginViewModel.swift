import Foundation

class LoginViewModel: ObservableObject {
    @Published var username = ""
    @Published var password = ""
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func login(completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "http://localhost:3000/api/login") else {
            errorMessage = "Invalid URL"
            completion(false)
            return
        }
        
        let parameters = [
            "username": username,
            "password": password
        ]
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters)
        } catch {
            errorMessage = "Failed to encode parameters"
            completion(false)
            return
        }
        
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.errorMessage = error.localizedDescription
                    completion(false)
                    return
                }
                
                guard let data = data else {
                    self?.errorMessage = "No data received"
                    completion(false)
                    return
                }
                
                do {
                    if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        let success = json["success"] as? Bool ?? false
                        if success {
                            completion(true)
                        } else {
                            self?.errorMessage = json["message"] as? String ?? "Login failed"
                            completion(false)
                        }
                    }
                } catch {
                    self?.errorMessage = "Failed to decode response"
                    completion(false)
                }
            }
        }.resume()
    }
} 