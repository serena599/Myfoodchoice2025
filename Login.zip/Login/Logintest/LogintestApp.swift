//
//  loginApp.swift
//  login
//
//  Created by ZhongzhengSU on 21/1/2025.
//

import SwiftUI

@main  // 标记应用程序入口点
struct loginApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()  // 设置初始视图
        }
    }
}
