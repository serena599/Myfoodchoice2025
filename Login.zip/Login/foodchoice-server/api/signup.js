const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise'); // 使用 promise 版本
const dotenv = require('dotenv');

dotenv.config();

// 创建数据库连接池
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// 创建用户表（如果不存在）
const createTable = `
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)`;

// 初始化数据库表
(async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(createTable);
        connection.release();
        console.log('用户表检查/创建成功');
    } catch (err) {
        console.error('创建用户表失败:', err);
    }
})();

// 注册API端点
router.post('/signup', async (req, res) => {
    const { username, email, phone, password } = req.body;

    // 基本输入验证
    if (!username || !email || !phone || !password) {
        return res.status(400).json({
            success: false,
            message: '所有字段都是必填的'
        });
    }

    // 验证邮箱格式
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return res.status(400).json({
            success: false,
            message: '无效的邮箱格式'
        });
    }

    // 验证手机号格式
    const phoneRegex = /^\d{11}$/;
    if (!phoneRegex.test(phone)) {
        return res.status(400).json({
            success: false,
            message: '无效的手机号格式'
        });
    }

    // 验证密码强度
    if (password.length < 8) {
        return res.status(400).json({
            success: false,
            message: '密码至少需要8个字符'
        });
    }

    try {
        const connection = await pool.getConnection();

        try {
            // 开始事务
            await connection.beginTransaction();

            // 检查用户名是否存在
            const [usernameResults] = await connection.query(
                'SELECT id FROM users WHERE username = ?',
                [username]
            );
            if (usernameResults.length > 0) {
                await connection.rollback();
                return res.status(400).json({
                    success: false,
                    message: '用户名已存在'
                });
            }

            // 检查邮箱是否存在
            const [emailResults] = await connection.query(
                'SELECT id FROM users WHERE email = ?',
                [email]
            );
            if (emailResults.length > 0) {
                await connection.rollback();
                return res.status(400).json({
                    success: false,
                    message: '邮箱已被注册'
                });
            }

            // 检查手机号是否存在
            const [phoneResults] = await connection.query(
                'SELECT id FROM users WHERE phone = ?',
                [phone]
            );
            if (phoneResults.length > 0) {
                await connection.rollback();
                return res.status(400).json({
                    success: false,
                    message: '手机号已被注册'
                });
            }

            // 插入新用户
            const [insertResult] = await connection.query(
                'INSERT INTO users (username, email, phone, password) VALUES (?, ?, ?, ?)',
                [username, email, phone, password]
            );

            // 提交事务
            await connection.commit();

            res.json({
                success: true,
                message: '注册成功',
                userId: insertResult.insertId
            });

        } catch (error) {
            // 如果发生错误，回滚事务
            await connection.rollback();
            throw error;
        } finally {
            // 释放连接
            connection.release();
        }

    } catch (error) {
        console.error('注册错误:', error);
        res.status(500).json({
            success: false,
            message: '注册失败，请稍后重试'
        });
    }
});

module.exports = router; 